
# AI_Chatbot_with_NLP (NLTK rule-based)

Simple internship Task-3 chatbot that uses NLTK for tokenization and lemmatization and a rule-like pattern-matching approach.

## Folder structure
```
AI_Chatbot_with_NLP/
├── chatbot.py
├── intents.json
├── requirements.txt
└── README.md
```

## Setup (run locally)
1. Create a virtual environment (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate   # macOS/Linux
   venv\Scripts\activate      # Windows
   ```
2. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```
3. (If needed) download NLTK data:
   ```bash
   python -m nltk.downloader punkt wordnet omw-1.4
   ```

## Run the chatbot
```bash
python chatbot.py
```
Type messages and press Enter. To run a short self-test instead:
```bash
python chatbot.py --test
```

## How it works (brief)
- `intents.json` contains tags, example patterns and responses.
- The script lemmatizes tokens of patterns and user input, and picks the intent with the highest fraction overlap.
- If the best match score is below a threshold, it replies with a fallback message.

## Customize
- Edit `intents.json` to add more patterns/responses.
- Tweak `get_response(..., threshold=...)` to make matching stricter or looser.

Enjoy! ~ CodTech Bot
