
import json
import random
import os
import sys

try:
    import nltk
    from nltk.stem import WordNetLemmatizer
    from nltk.tokenize import word_tokenize
except Exception as e:
    print("NLTK is required but not installed. Run: pip install -r requirements.txt")
    raise

lemmatizer = WordNetLemmatizer()

# try to download required NLTK data (will work if internet is available)
try:
    nltk.data.find("tokenizers/punkt")
    nltk.data.find("corpora/wordnet")
except LookupError:
    print("Downloading NLTK data (punkt, wordnet). If this fails, run: python -m nltk.downloader punkt wordnet omw-1.4")
    try:
        nltk.download("punkt")
        nltk.download("wordnet")
        nltk.download("omw-1.4")
    except:
        pass

BASE_DIR = os.path.dirname(__file__)
INTENTS_FILE = os.path.join(BASE_DIR, "intents.json")

with open(INTENTS_FILE, "r", encoding="utf-8") as f:
    data = json.load(f)

# prepare simple patterns -> lemmatized sets
def tokenize_and_lemmatize(sentence):
    tokens = word_tokenize(sentence.lower())
    lemmas = [lemmatizer.lemmatize(t) for t in tokens if t.isalnum()]
    return lemmas

intent_patterns = {}
for intent in data["intents"]:
    patterns = []
    for p in intent.get("patterns", []):
        patterns.append(set(tokenize_and_lemmatize(p)))
    intent_patterns[intent["tag"]] = {
        "patterns": patterns,
        "responses": intent.get("responses", [])
    }

def classify(sentence):
    sent_tokens = set(tokenize_and_lemmatize(sentence))
    best_tag = None
    best_score = 0.0
    # simple scoring: max overlap with any pattern for each intent
    for tag, info in intent_patterns.items():
        for pat in info["patterns"]:
            if not pat: 
                continue
            overlap = len(sent_tokens & pat) / len(pat)  # fraction matched
            if overlap > best_score:
                best_score = overlap
                best_tag = tag
    return best_tag, best_score

def get_response(sentence, threshold=0.2):
    tag, score = classify(sentence)
    if tag is None or score < threshold:
        return "Sorry, I didn't understand that. Can you rephrase?"
    responses = intent_patterns[tag]["responses"]
    return random.choice(responses)

def interactive_chat():
    print("Welcome to CodTech NLTK Chatbot (type 'quit' or 'exit' to stop)")
    while True:
        try:
            inp = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nExiting...")
            break
        if not inp:
            continue
        if inp.lower() in ["quit", "exit"]:
            print("Bot: Goodbye!")
            break
        resp = get_response(inp)
        print("Bot:", resp)

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--test":
        # quick self-test
        tests = [
            "hello",
            "what is your name",
            "tell me about the internship task",
            "thanks",
            "bye",
            "how are you"
        ]
        for t in tests:
            print("You:", t)
            print("Bot:", get_response(t))
            print("---")
    else:
        interactive_chat()
